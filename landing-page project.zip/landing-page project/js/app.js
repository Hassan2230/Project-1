/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
 */

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
 */

//Define Global Variables
const Nav_List = document.querySelector("#navbar__list");
const sections = document.querySelectorAll("section");
const div1 = document.createElement("div");

/**
 * End Global Variables
 * Start Helper Functions
 */

// build the nav
for (const section of sections) {
    const Section_ID = section.getAttribute("id");
    const Section_title = section.getAttribute("data-nav");
    const List_Item = document.createElement("li");
    const List_Link = document.createElement("a");

    List_Link.href = `#${Section_ID}`;
    List_Link.textContent = Section_title;

    List_Link.className = "menu__link";

    // Scroll to section on link click
    List_Link.addEventListener("click", function(event) {
        event.preventDefault();
        section.scrollIntoView({ behavior: "smooth" });
    });
    List_Item.appendChild(List_Link);
    div1.appendChild(List_Item);
}

Nav_List.appendChild(div1);

// Add class 'active' to section when near top of viewport
const Links = document.querySelectorAll("a .menu__link");

window.addEventListener("scroll", function() {
    for (section of sections) {
        const sectionTop = section.getBoundingClientRect().top;
        section.classList.remove("your-active-class");
        if (sectionTop >= 0 && sectionTop < 250) {
            section.classList.add("your-active-class");
            Links.forEach((Link) => {
                if (Link.textContent === section.dataset.nav) {
                    Link.classList.add("active-class");
                } else {
                    Link.classList.remove("active-class");
                }
            });
        } else {
            section.classList.remove("your-active-class");
        }
    }
});
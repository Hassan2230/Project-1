# Landing Page Project

## Project Description

This project is to build a multi-section landing page, with a dynamically updating navigational menu, based on the amount of content that is added to the page.

## Author

Hassan Mostafa

## Used Technologies

The starter project has some HTML and CSS styling and javascript file to display a dynamic version of the Landing Page project.
